
  # UI Component Design

  This is a code bundle for UI Component Design. The original project is available at https://www.figma.com/design/gC9ClMs5M8vska0OYoQRrB/UI-Component-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  