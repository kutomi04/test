import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./components/ui/table";
import { Badge } from "./components/ui/badge";
import { Alert, AlertDescription } from "./components/ui/alert";
import { AlertTriangle } from "lucide-react";

interface InventoryItem {
  id: string;
  productName: string;
  category: string;
  currentStock: number;
  minStock: number;
  unit: string;
}

const MOCK_INVENTORY: InventoryItem[] = [
  {
    id: "B001",
    productName: "おむつ 新生児用 テープ",
    category: "おむつ",
    currentStock: 3,
    minStock: 10,
    unit: "パック",
  },
  {
    id: "B002",
    productName: "おむつ Sサイズ テープ",
    category: "おむつ",
    currentStock: 8,
    minStock: 12,
    unit: "パック",
  },
  {
    id: "B003",
    productName: "おむつ Mサイズ パンツ",
    category: "おむつ",
    currentStock: 15,
    minStock: 15,
    unit: "パック",
  },
  {
    id: "B004",
    productName: "おむつ Lサイズ パンツ",
    category: "おむつ",
    currentStock: 12,
    minStock: 10,
    unit: "パック",
  },
  {
    id: "W001",
    productName: "おしりふき 水99% 厚手",
    category: "おしりふき",
    currentStock: 5,
    minStock: 20,
    unit: "個",
  },
  {
    id: "W002",
    productName: "おしりふき 純水100% 詰替",
    category: "おしりふき",
    currentStock: 25,
    minStock: 15,
    unit: "個",
  },
  {
    id: "W003",
    productName: "おしりふき トイレに流せる",
    category: "おしりふき",
    currentStock: 2,
    minStock: 10,
    unit: "個",
  },
  {
    id: "S001",
    productName: "除菌シート アルコール配合",
    category: "除菌シート",
    currentStock: 8,
    minStock: 15,
    unit: "個",
  },
  {
    id: "S002",
    productName: "除菌シート ノンアルコール",
    category: "除菌シート",
    currentStock: 4,
    minStock: 12,
    unit: "個",
  },
  {
    id: "S003",
    productName: "除菌シート 携帯用 20枚",
    category: "除菌シート",
    currentStock: 1,
    minStock: 8,
    unit: "個",
  },
];

export default function App() {
  const [inventory] = useState<InventoryItem[]>(MOCK_INVENTORY);

  const lowStockItems = inventory.filter(
    (item) => item.currentStock < item.minStock
  );

  const isLowStock = (item: InventoryItem) =>
    item.currentStock < item.minStock;

  const getStockStatus = (item: InventoryItem) => {
    const percentage = (item.currentStock / item.minStock) * 100;
    if (percentage < 50) return "critical";
    if (percentage < 100) return "warning";
    return "normal";
  };

  return (
    <div className="size-full bg-gray-50 p-8 overflow-auto">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">在庫管理システム</h1>
          <p className="text-gray-600">
            商品の在庫状況を確認・管理します
          </p>
        </div>

        {lowStockItems.length > 0 && (
          <Alert className="mb-6 bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>{lowStockItems.length}件</strong>
              の商品が最低在庫数を下回っています。早急な補充が必要です。
            </AlertDescription>
          </Alert>
        )}

        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b">
            <h2 className="text-xl">在庫一覧</h2>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">商品コード</TableHead>
                <TableHead>商品名</TableHead>
                <TableHead>カテゴリー</TableHead>
                <TableHead className="text-right">現在庫数</TableHead>
                <TableHead className="text-right">最低在庫数</TableHead>
                <TableHead className="text-center">ステータス</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inventory.map((item) => {
                const lowStock = isLowStock(item);
                const status = getStockStatus(item);

                return (
                  <TableRow
                    key={item.id}
                    className={
                      lowStock
                        ? "bg-red-50 hover:bg-red-100 border-l-4 border-l-red-500"
                        : ""
                    }
                  >
                    <TableCell className="font-medium">{item.id}</TableCell>
                    <TableCell>{item.productName}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell
                      className={`text-right ${
                        lowStock ? "text-red-700 font-bold" : ""
                      }`}
                    >
                      {item.currentStock} {item.unit}
                    </TableCell>
                    <TableCell className="text-right text-gray-600">
                      {item.minStock} {item.unit}
                    </TableCell>
                    <TableCell className="text-center">
                      {status === "critical" && (
                        <Badge className="bg-red-600">緊急補充</Badge>
                      )}
                      {status === "warning" && (
                        <Badge className="bg-orange-500">要補充</Badge>
                      )}
                      {status === "normal" && (
                        <Badge className="bg-green-600">適正</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          <div className="p-4 border-t bg-gray-50 text-sm text-gray-600">
            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-600 rounded"></div>
                <span>適正在庫（100%以上）</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-orange-500 rounded"></div>
                <span>要補充（50-99%）</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-600 rounded"></div>
                <span>緊急補充（50%未満）</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}